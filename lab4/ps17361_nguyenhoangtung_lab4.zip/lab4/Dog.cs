namespace lab4
{
    public class Dog
    {
        public string Name { get; set; }
        public int Age { get; set; }
    }
}