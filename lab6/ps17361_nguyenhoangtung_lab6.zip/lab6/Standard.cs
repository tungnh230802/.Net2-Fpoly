namespace lab6
{
    public class Standard
    {
        public int StandardId { get; set; }
        public string StandardName { get; set; }
    }
}