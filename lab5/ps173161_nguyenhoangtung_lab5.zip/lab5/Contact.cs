namespace lab5
{
    public class Contact
    {
        public int Age {get;set;}
        public string FirstName {get;set;}
        public string LastName {get;set;}
        public string Address {get;set;}
    }
}