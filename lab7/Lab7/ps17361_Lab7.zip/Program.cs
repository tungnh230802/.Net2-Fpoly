﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using static System.Console;
using System.Text;

namespace Lab7
{
    class Program
    {     
        static void Bai1()
        {
            int[] n1 = new int[10] { 0, 1, 2, 3, 4, 5, 6, 7, 8, 9 };
            //-Viết chương trình xuất bình phương các số chẵn > 4
            WriteLine("-Bài1-A:chương trình xuất bình phương các số chẵn > 4");
            var bai1 = from n in n1
                       where (n > 4 && n %2 ==0)
                       select n * n;
            bai1.ToList().ForEach(x => Write(x + " "));
            WriteLine("\n----------------------------");

            WriteLine("-Bài2-B:xuất ra màn hình số lần xuất hiện của từng ký tự trong chuỗi");
            Write("mời nhập chuỗi bất kỳ: ");
            string str = ReadLine();
            var bai1b = from s in str.Trim().Replace(" ", "").ToCharArray()
                        group s by s;
            WriteLine("Số lần xuất hiện của các ký tự:");
            foreach (var gr in bai1b)
            {
                WriteLine($"Ký tự {gr.Key}: {gr.Count()} lần");
            }
            WriteLine("\n----------------------------");

            WriteLine("Bài 1-C:chương trình nhận vào một chuỗi ký tự có các chuỗi con có viết hoa, xuất ra \n" +
                "màn hình các chuỗi con được viết hoa");

            Write("mời nhập chuỗi bất kỳ: ");
            string str2 = ReadLine();

            var bai1C = str2.Split(' ')
                .Where(x => String.Equals(x, x.ToUpper(),
                StringComparison.Ordinal));
            WriteLine("The UPPER CASE words are: ");
            foreach(string s in bai1C)
            {
                WriteLine(s);
            }
        }

        static void Bai2a()
        {
            using (var db = new lab7DBDataContext(@"Data Source=desktop-2v5f3ca\tungnh230802;Initial Catalog=northwind;
                 Integrated Security=true"))
            {
                var customers = db.Customers.ToList();
                var orders = db.Orders.ToList();
                var bai1 = from c in customers
                           join o in orders
                           on c.CustomerID equals o.CustomerID
                           select new
                           {
                               ContactName = c.ContactName,
                               ShipName = o.ShipName,
                           };
                WriteLine("----------------bai2A----------------");
                WriteLine($"{"Contact Name",-20}\t{"Ship Name",-20}");

                foreach(var item in bai1)
                {
                    Thread.Sleep(10);
                    WriteLine($"{item.ContactName,-20}\t{item.ShipName,-20}");
                }
            }
        }

        static void Bai2b()
        {
            using (var db = new lab7DBDataContext(@"Data Source=desktop-2v5f3ca\tungnh230802;Initial Catalog=northwind;
                 Integrated Security=true"))
            {

                var customer = new Customer()
                {
                    CustomerID = "Fpoly",
                    CompanyName = "FPT",
                };

                db.Customers.InsertOnSubmit(customer);
                db.SubmitChanges();

                WriteLine("thêm dữ liệu thành công");

                var customers = db.Customers.ToList().Where(x => x.CustomerID == "Fpoly");

                foreach (var item in customers)
                {
                    WriteLine(item.CustomerID + "\t" + item.CompanyName);
                }
            }
        }

        static void Bai2c()
        {
            using (var db = new lab7DBDataContext(@"Data Source=desktop-2v5f3ca\tungnh230802;Initial Catalog=northwind;
                 Integrated Security=true"))
            {
                var customer = db.Customers
                                    .Where(c=>c.CustomerID == "Fpoly")
                                    .FirstOrDefault();
                if (customer != null)
                {
                    customer.CompanyName = "FE";
                    db.SubmitChanges();

                    WriteLine("Cập nhật dữ liệu thành công");

                    var customers = db.Customers.ToList().Where(x => x.CustomerID == "Fpoly");

                    foreach (var item in customers)
                    {
                        WriteLine(item.CustomerID + "\t" + item.CompanyName);
                    }
                }
                else
                {
                    WriteLine("không tìm thấy id Fpoly");
                }
            }
        }

        static void Bai2d()
        {
            using (var db = new lab7DBDataContext(@"Data Source=desktop-2v5f3ca\tungnh230802;Initial Catalog=northwind;
                 Integrated Security=true"))
            {
                var customer = db.Customers
                                    .Where(c => c.CustomerID == "ALFKI")
                                    .FirstOrDefault();
                if (customer != null)
                {
                    db.Customers.DeleteOnSubmit(customer);
                    try
                    {
                        db.SubmitChanges();
                        WriteLine("xóa dữ liệu thành công");

                    }
                    catch
                    {
                        WriteLine("không thể xóa!");
                    }
                }
                else
                {
                    WriteLine("không tìm thấy customer id alfki");
                }
                }
        }

        static void Main(string[] args)
        {
            OutputEncoding = Encoding.UTF8;
            //Bai1();
            Bai2a();
            ReadLine();
        }
    }
}
